/Users/apple/.virtualenvs/test_python3/bin/python /Users/apple/Desktop/code/sun.py
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type"/>
<title>最新回复_阳光热线问政平台_东莞阳光网</title>
<meta content="问政 阳光问政 网络问政 最新回复" name="keywords"/>
<link href="/images/wzimg/css.css" rel="stylesheet" type="text/css"/>
<link href="/css/common.css" rel="stylesheet" type="text/css"/>
<link href="/css/morelist.css" rel="stylesheet" type="text/css"/>
</head>
<body>
<div class="top1"><script language="JavaScript" src="http://www.sun0769.com/js/SubjectMenu2_950.js" type="text/javascript"></script></div>
<div class="top2"><img height="226" src="/images/wzimg/banner.jpg" width="960"/></div>
<div class="top3"><img alt="" border="0" height="20" id="menu_r1_c2" name="menu_r1_c1" src="/images/wzimg/menu_r1_c1.jpg" width="960"/></div>
<table align="center" bgcolor="#e7f4fd" border="0" cellpadding="0" cellspacing="0" width="960">
<tr>
<td><a class="menu_1" href="http://wz.sun0769.com/" title="阳光问政首页"></a></td>
<td><a class="menu_2" href="http://d.news.sun0769.com/hotline/review.asp" target="_blank" title="在线访谈"></a></td>
<td><a class="menu_3" href="http://wz.sun0769.com/html/top/report.shtml" title="问题反映"></a></td>
<td><a class="menu_4" href="http://wz.sun0769.com/html/top/reply.shtml" title="最新回复"></a></td>
<td><a class="menu_5" href="http://wz.sun0769.com/html/top/sheqing.shtml" title="论坛"></a></td>
<td><a class="menu_6" href="http://wz.sun0769.com/html/top/ruse.shtml" title="谏言良策"></a></td>
<td><a class="menu_9" href="http://wz.sun0769.com/html/top/department.shtml" title="问政部门"></a></td>
<td><a class="menu_10" href="http://wz.sun0769.com/html/top/town.shtml" title="问政镇街"></a></td>
<td><a class="menu_11" href="http://d.news.sun0769.com/hkt/review.asp" target="_blank" title="阳光会客厅"></a></td>
</tr>
</table>
<div class="top5"><img alt="" border="0" height="10" id="menu_r3_c1" name="menu_r3_c1" src="/images/wzimg/menu_r3_c1.jpg" width="960"/></div>
<div class="pagecenter" id="morelist">
<div class="greyframe">
<div class="ctitle">
<div class="cleft"><strong class="titwh14">最新回复</strong></div>
<div class="cright"><a class="t12red" href="/index.php/wenzheng/" target="_blank"><strong>我要问政</strong></a> </div>
<div class="clear"></div>
</div>
<table bgcolor="#f4faff" border="0" cellpadding="1" cellspacing="0" class="box1" width="100%">
<tbody>
<tr>
<td align="center" height="25" width="64">编号</td>
<td align="left" width="582">
<p>标题</p></td>
<td align="middle" class="t12y" width="48">状态</td>
<td align="left" class="t12y" width="104">网友</td>
<td align="middle" class="t12y" width="140">时间</td>
</tr></tbody>
</table>
<table bgcolor="#E0E0E9" border="0" cellpadding="0" cellspacing="0" width="940">
<tr>
<td align="center" bgcolor="#FFFFFF" valign="top"><table bgcolor="#FBFEFF" border="0" cellpadding="1" cellspacing="0" width="98%">
<tr>
<td align="center" bgcolor="#FFFFFF" height="30" width="53">199739</td>
<td align="left" width="590"><a class="red14" href="/index.php/question/questionType?type=4" target="_blank">[投诉]</a> <a class="news14" href="http://wz.sun0769.com/html/question/201810/390196.shtml" target="_blank" title="下漕长洲村建筑材料／建筑垃圾乱放影响车辆出行">下漕长洲村建筑材料／建筑垃圾乱放影响车辆出行<font color="red">[图]</font></a> <a class="t12h" href="/index.php/department?type=201&amp;departmentid=163">望牛墩</a></td>
<td align="left" class="t12h" width="50"><span class="qred">已回复</span></td>
<td align="left" class="t12h" width="105">sulee</td>
<td align="center" class="t12wh" width="121">2018-11-07 17:55:01</td>
</tr>
<tr>
<td align="center" bgcolor="#FFFFFF" height="30" width="53">198439</td>
<td align="left" width="590"><a class="red14" href="/index.php/question/questionType?type=4" target="_blank">[投诉]</a> <a class="news14" href="http://wz.sun0769.com/html/question/201810/388429.shtml" target="_blank" title="东城光明潭头新村东29号住宅区乱放养家禽">东城光明潭头新村东29号住宅区乱放养家禽<font color="red">[图]</font></a> <a class="t12h" href="/index.php/department?type=201&amp;departmentid=141">东城</a></td>
<td align="left" class="t12h" width="50"><span class="qred">已回复</span></td>
<td align="left" class="t12h" width="105">蝴蝶菲</td>
<td align="center" class="t12wh" width="121">2018-11-07 17:54:21</td>
</tr>
<tr>
<td align="center" bgcolor="#FFFFFF" height="30" width="53">200136</td>
<td align="left" width="590"><a class="red14" href="/index.php/question/questionType?type=4" target="_blank">[投诉]</a> <a class="news14" href="http://wz.sun0769.com/html/question/201810/390740.shtml" target="_blank" title="我家每天在地震">我家每天在地震</a> <a class="t12h" href="/index.php/department?type=201&amp;departmentid=163">望牛墩</a></td>
<td align="left" class="t12h" width="50"><span class="qred">已回复</span></td>
<td align="left" class="t12h" width="105">潇洒小姐</td>
<td align="center" class="t12wh" width="121">2018-11-07 17:52:50</td>
</tr>
<tr>
<td align="center" bgcolor="#FFFFFF" height="30" width="53">200193</td>
<td align="left" width="590"><a class="red14" href="/index.php/question/questionType?type=3" target="_blank">[咨询]</a> <a class="news14" href="http://wz.sun0769.com/html/question/201810/390813.shtml" target="_blank" title="望牛墩下漕长洲村征地补偿">望牛墩下漕长洲村征地补偿</a> <a class="t12h" href="/index.php/department?type=201&amp;departmentid=163">望牛墩</a></td>
<td align="left" class="t12h" width="50"><span class="qred">已回复</span></td>
<td align="left" class="t12h" width="105">有话好好说mc</td>
<td align="center" class="t12wh" width="121">2018-11-07 17:52:45</td>
</tr>
<tr>
<td align="center" bgcolor="#FFFFFF" height="30" width="53">199797</td>
<td align="left" width="590"><a class="red14" href="/index.php/question/questionType?type=1" target="_blank">[建议]</a> <a class="news14" href="http://wz.sun0769.com/html/question/201810/390265.shtml" target="_blank" title="望牛墩路口 环城北路入蕉利与望牛墩镇中路交汇处没有红绿灯">望牛墩路口 环城北路入蕉利与望牛墩镇中路交汇处没有红绿灯<font color="red">[图]</font></a> <a class="t12h" href="/index.php/department?type=201&amp;departmentid=163">望牛墩</a></td>
<td align="left" class="t12h" width="50"><span class="qred">已回复</span></td>
<td align="left" class="t12h" width="105">David1633</td>
<td align="center" class="t12wh" width="121">2018-11-07 17:52:18</td>
</tr>
<tr>
<td align="center" bgcolor="#FFFFFF" height="30" width="53">200376</td>
<td align="left" width="590"><a class="red14" href="/index.php/question/questionType?type=1" target="_blank">[建议]</a> <a class="news14" href="http://wz.sun0769.com/html/question/201810/391053.shtml" target="_blank" title="路中间护栏设置可掉头路口">路中间护栏设置可掉头路口</a> <a class="t12h" href="/index.php/department?type=201&amp;departmentid=164">谢岗</a></td>
<td align="left" class="t12h" width="50"><span class="qred">已回复</span></td>
<td align="left" class="t12h" width="105">gdgxgd</td>
<td align="center" class="t12wh" width="121">2018-11-07 17:51:27</td>
</tr>
<tr>
<td align="center" bgcolor="#FFFFFF" height="30" width="53">198606</td>
<td align="left" width="590"><a class="red14" href="/index.php/question/questionType?type=4" target="_blank">[投诉]</a> <a class="news14" href="http://wz.sun0769.com/html/question/201810/388654.shtml" target="_blank" title="南城宏远社区活力康城门口商铺长期占道经营">南城宏远社区活力康城门口商铺长期占道经营<font color="red">[图]</font></a> <a class="t12h" href="/index.php/department?type=201&amp;departmentid=152">南城</a></td>
<td align="left" class="t12h" width="50"><span class="qred">已回复</span></td>
<td align="left" class="t12h" width="105">kala769</td>
<td align="center" class="t12wh" width="121">2018-11-07 17:51:21</td>
</tr>
<tr>
<td align="center" bgcolor="#FFFFFF" height="30" width="53">198528</td>
<td align="left" width="590"><a class="red14" href="/index.php/question/questionType?type=4" target="_blank">[投诉]</a> </td></tr></table></td></tr></table></div></div></body></html>
7

Process finished with exit code 0
